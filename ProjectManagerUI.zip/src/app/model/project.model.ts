export class Project {
    
    projectId: number;
    project: string;
    parentTaskName: string;
    managerStr: string;
    numberOfTasks: number;
    priority: number;
    startDateStr: string;
    endDateStr: string;
    completed: string;
    suspendFlag: string;

    constructor() {
        
    }
}