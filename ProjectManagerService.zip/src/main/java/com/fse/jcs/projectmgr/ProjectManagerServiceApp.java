package com.fse.jcs.projectmgr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectManagerServiceApp 
{
    public static void main( String[] args )
    {
       SpringApplication.run(ProjectManagerServiceApp.class, args);
    }
}
